//
//  DashboardView.swift
//  Rivet1
//

import SwiftUI

struct DashboardView: View {
    @State private var streakCount = 7
    @State private var screenTimeLabel = "5h 08m"
    @State private var appUsage: [AppUsageStat] = DashboardView.sampleAppUsage

    @Binding var tasks: [FocusTask]
    @Binding var completedTask: FocusTask?

    var onStartFocus: (() -> Void)?
    var onAddTask: (() -> Void)?

    var body: some View {
        GeometryReader { geometry in
            ScrollView(.vertical, showsIndicators: false) {
                VStack(spacing: 0) {
                    headerSection(topInset: geometry.safeAreaInsets.top)
                    contentSection
                }
            }
            .background(AppTheme.Colors.screenBackground)
        }
        .ignoresSafeArea(edges: .top)
        .background(AppTheme.Colors.headerTop.ignoresSafeArea(edges: .top))
    }

    // MARK: - Header

    private func headerSection(topInset: CGFloat) -> some View {
        VStack(spacing: 0) {
            HStack(alignment: .center) {
                Text("Dashboard")
                    .font(AppFont.medium(16))
                    .foregroundStyle(AppTheme.Colors.headerTitle)

                Spacer()

                StreakBadge(count: streakCount)
            }
            .padding(.horizontal, 20)
            .padding(.top, topInset + 24)

            VStack(spacing: 6) {
                Text(screenTimeLabel)
                    .font(AppFont.bold(52))
                    .foregroundStyle(.white)
                    .tracking(-0.5)

                Text("SCREEN TIME TODAY")
                    .font(AppFont.semibold(12))
                    .foregroundStyle(AppTheme.Colors.accentCyan)
                    .tracking(1.2)
            }
            .padding(.top, 28)
            .padding(.bottom, 28)

            PrimaryGradientButton(title: "Start Focus session") {
                onStartFocus?()
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 22)
        }
        .padding(.bottom, 8)
        .background(
            UnevenRoundedRectangle(
                topLeadingRadius: 0,
                bottomLeadingRadius: AppTheme.CornerRadius.headerBottom,
                bottomTrailingRadius: AppTheme.CornerRadius.headerBottom,
                topTrailingRadius: 0,
                style: .continuous
            )
            .fill(AppTheme.Colors.headerGradient)
        )
    }

    // MARK: - Body Content

    private var contentSection: some View {
        VStack(alignment: .leading, spacing: 22) {
            appUsageSection
            todaysTasksSection
        }
        .padding(.top, 18)
        .padding(.bottom, 24)
    }

    private var appUsageSection: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 12) {
                ForEach(appUsage) { stat in
                    AppUsageCard(stat: stat)
                }
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 4)
        }
    }

    private var todaysTasksSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("TODAY'S TASKS")
                    .font(AppFont.semibold(12))
                    .foregroundStyle(AppTheme.Colors.textMuted)
                    .tracking(0.8)

                Spacer()

                Button {
                    onAddTask?()
                } label: {
                    Text("+ Add task")
                        .font(AppFont.semibold(13))
                        .foregroundStyle(AppTheme.Colors.softBlueText)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 7)
                        .background(AppTheme.Colors.softBlueFill)
                        .clipShape(Capsule())
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 20)

            LazyVStack(spacing: 12) {
                ForEach($tasks) { $task in
                    TaskRowCard(
                        task: $task,
                        onToggleExpand: {
                            withAnimation(.easeInOut(duration: 0.22)) {
                                task.isExpanded.toggle()
                            }
                        },
                        onToggleSubtask: { subtaskID in
                            handleSubtaskToggle(for: &task, subtaskID: subtaskID)
                        }
                    )
                }
            }
            .padding(.horizontal, 20)
        }
    }

    private func handleSubtaskToggle(for task: inout FocusTask, subtaskID: UUID) {
        guard let index = task.subtasks.firstIndex(where: { $0.id == subtaskID }) else { return }

        let wasComplete = task.isFullyComplete
        task.subtasks[index].isCompleted.toggle()

        if !wasComplete && task.isFullyComplete {
            withAnimation(.easeInOut(duration: 0.28)) {
                completedTask = task
            }
        }
    }
}

// MARK: - Sample Data

extension DashboardView {
    static let sampleAppUsage: [AppUsageStat] = [
        AppUsageStat(
            name: "Instagram",
            durationLabel: "1H 58M",
            iconAssetName: "InstagramAppIcon"
        ),
        AppUsageStat(
            name: "TikTok",
            durationLabel: "1H 12M",
            iconAssetName: "TikTokAppIcon"
        ),
        AppUsageStat(
            name: "Safari",
            durationLabel: "48M",
            iconAssetName: "SafariAppIcon"
        ),
        AppUsageStat(
            name: "YouTube",
            durationLabel: "22M",
            iconAssetName: "YouTubeAppIcon",
            isDimmed: true
        )
    ]

    static let sampleTasks: [FocusTask] = [
        FocusTask(
            title: "Read Atomic Habits",
            accentColor: AppTheme.Colors.accentBlue,
            priority: .medium,
            verification: .textHonor(
                question: "What's the main thing you took away from your reading?"
            ),
            subtasks: [
                FocusSubtask(title: "Read chapter 1", isCompleted: false),
                FocusSubtask(title: "Highlight key ideas", isCompleted: false),
                FocusSubtask(title: "Write a short summary", isCompleted: false)
            ],
            isExpanded: true
        ),
        FocusTask(
            title: "Clean the bedroom",
            accentColor: AppTheme.Colors.accentOrange,
            priority: .high,
            verification: .photo,
            subtasks: [
                FocusSubtask(title: "Make the bed", isCompleted: false),
                FocusSubtask(title: "Put clothes away", isCompleted: false),
                FocusSubtask(title: "Wipe surfaces", isCompleted: false)
            ],
            isExpanded: false
        )
    ]
}

#Preview {
    @Previewable @State var tasks = DashboardView.sampleTasks
    @Previewable @State var completedTask: FocusTask? = nil
    DashboardView(tasks: $tasks, completedTask: $completedTask)
}
