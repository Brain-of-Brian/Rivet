//
//  TaskCompleteSheet.swift
//  Rivet1
//

import PhotosUI
import SwiftUI
import UIKit

struct TaskCompleteSheet: View {
    let task: FocusTask
    var onVerified: (() -> Void)?
    var onDismiss: (() -> Void)?

    @State private var reflectionText = ""
    @State private var isReviewing = false
    @State private var reviewResult: TaskVerificationResult?
    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var capturedImage: UIImage?
    @State private var showCamera = false
    @FocusState private var isReflectionFocused: Bool

    private let verificationService = TaskVerificationService()

    var body: some View {
        VStack(spacing: 0) {
            Capsule()
                .fill(Color.black.opacity(0.14))
                .frame(width: 40, height: 5)
                .padding(.top, 14)
                .padding(.bottom, 24)

            header

            Group {
                switch task.verification {
                case .photo:
                    photoContent
                case .textHonor(let question):
                    reflectionContent(question: question)
                }
            }
            .padding(.top, 28)
        }
        .padding(.horizontal, 24)
        .padding(.bottom, 12)
        .frame(maxWidth: .infinity, alignment: .top)
        .fullScreenCover(isPresented: $showCamera) {
            CameraPicker(image: $capturedImage)
                .ignoresSafeArea()
        }
        .onChange(of: capturedImage) { _, image in
            guard let image else { return }
            Task { await submitPhoto(image) }
        }
        .onChange(of: selectedPhotoItem) { _, item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let image = UIImage(data: data) {
                    capturedImage = image
                }
            }
        }
    }

    // MARK: - Header

    private var header: some View {
        HStack(alignment: .center, spacing: 14) {
            ZStack {
                Circle()
                    .fill(headerIconFill)
                    .frame(width: 48, height: 48)

                Image(systemName: headerIconName)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(headerIconColor)
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(headerStatusLabel)
                    .font(AppFont.semibold(11))
                    .foregroundStyle(AppTheme.Colors.textMuted)
                    .tracking(1.0)

                Text(task.title)
                    .font(AppFont.bold(20))
                    .foregroundStyle(AppTheme.Colors.textPrimary)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }

            Spacer(minLength: 8)

            AIBadge()
        }
    }

    private var headerStatusLabel: String {
        if let reviewResult {
            return reviewResult.passed ? "VERIFIED" : "NOT PROVEN"
        }
        return "TASK COMPLETE"
    }

    private var headerIconName: String {
        if let reviewResult {
            return reviewResult.passed ? "checkmark" : "xmark"
        }
        return "checkmark"
    }

    private var headerIconFill: Color {
        if let reviewResult {
            return reviewResult.passed
                ? AppTheme.Colors.successMintFill
                : Color(red: 1.0, green: 0.88, blue: 0.88)
        }
        switch task.verification {
        case .photo: return AppTheme.Colors.successMintFill
        case .textHonor: return AppTheme.Colors.successBlueFill
        }
    }

    private var headerIconColor: Color {
        if let reviewResult {
            return reviewResult.passed
                ? AppTheme.Colors.successMintIcon
                : AppTheme.Colors.accentRed
        }
        switch task.verification {
        case .photo: return AppTheme.Colors.successMintIcon
        case .textHonor: return AppTheme.Colors.successBlueIcon
        }
    }

    // MARK: - Photo

    private var photoContent: some View {
        VStack(spacing: 22) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Why a photo?")
                    .font(AppFont.bold(16))
                    .foregroundStyle(AppTheme.Colors.infoCardTitle)

                Text("This task involves a physical result — Rivit AI needs to see it to verify completion.")
                    .font(AppFont.regular(14))
                    .foregroundStyle(AppTheme.Colors.textSecondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18)
            .background(AppTheme.Colors.infoCardFill)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

            if let capturedImage, reviewResult == nil, !isReviewing {
                Image(uiImage: capturedImage)
                    .resizable()
                    .scaledToFill()
                    .frame(height: 140)
                    .frame(maxWidth: .infinity)
                    .clipped()
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            }

            if let reviewResult {
                resultBanner(reviewResult)
            }

            if isReviewing {
                HStack(spacing: 10) {
                    ProgressView()
                    Text("Checking photo with AI…")
                        .font(AppFont.medium(14))
                        .foregroundStyle(AppTheme.Colors.textSecondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 8)
            } else if reviewResult?.passed == true {
                Button {
                    onVerified?()
                    onDismiss?()
                } label: {
                    Text("Done")
                        .font(AppFont.semibold(16))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(AppTheme.Colors.successMintIcon)
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                }
                .buttonStyle(.plain)
            } else if reviewResult?.passed == false {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        reviewResult = nil
                        capturedImage = nil
                        selectedPhotoItem = nil
                    }
                } label: {
                    Text("Try another photo")
                        .font(AppFont.semibold(16))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(AppTheme.Colors.focusGradient)
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                }
                .buttonStyle(.plain)
            } else {
                VStack(spacing: 10) {
                    Button {
                        showCamera = true
                    } label: {
                        HStack(spacing: 8) {
                            Image(systemName: "camera.fill")
                                .font(.system(size: 14, weight: .bold))
                            Text("Take a photo to verify")
                                .font(AppFont.semibold(16))
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(AppTheme.Colors.focusGradient)
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                        .shadow(color: AppTheme.Shadow.glow, radius: 16, x: 0, y: 8)
                    }
                    .buttonStyle(.plain)

                    PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                        Text("Choose from library")
                            .font(AppFont.semibold(14))
                            .foregroundStyle(AppTheme.Colors.navAction)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                    }
                }
            }

            Text("Your photo is analyzed privately for this check")
                .font(AppFont.regular(12))
                .foregroundStyle(AppTheme.Colors.textMuted)
                .multilineTextAlignment(.center)
                .frame(maxWidth: .infinity)
                .padding(.top, 4)
        }
    }

    // MARK: - Text / honor proof

    private func reflectionContent(question: String) -> some View {
        VStack(spacing: 18) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Prove it")
                    .font(AppFont.semibold(14))
                    .foregroundStyle(AppTheme.Colors.infoCardTitle)

                Text(question)
                    .font(AppFont.medium(15))
                    .foregroundStyle(AppTheme.Colors.textPrimary)
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(18)
            .background(AppTheme.Colors.infoCardFill)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))

            if let reviewResult {
                resultBanner(reviewResult)
            } else {
                TextField("Type your answer...", text: $reflectionText, axis: .vertical)
                    .font(AppFont.regular(15))
                    .foregroundStyle(AppTheme.Colors.textPrimary)
                    .lineLimit(3...5)
                    .padding(16)
                    .focused($isReflectionFocused)
                    .disabled(isReviewing)
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .stroke(AppTheme.Colors.fieldBorder, lineWidth: 1)
                    )
            }

            if reviewResult?.passed == true {
                Button {
                    onVerified?()
                    onDismiss?()
                } label: {
                    Text("Done")
                        .font(AppFont.semibold(16))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(AppTheme.Colors.successMintIcon)
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                }
                .buttonStyle(.plain)
            } else if reviewResult?.passed == false {
                Button {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        reviewResult = nil
                    }
                } label: {
                    Text("Try again")
                        .font(AppFont.semibold(16))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(AppTheme.Colors.softLavenderButton)
                        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                }
                .buttonStyle(.plain)
            } else {
                Button {
                    Task { await submitForReview(question: question) }
                } label: {
                    HStack(spacing: 8) {
                        if isReviewing {
                            ProgressView()
                                .tint(.white)
                        }
                        Text(isReviewing ? "Reviewing…" : "Submit for AI review")
                            .font(AppFont.semibold(16))
                    }
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(AppTheme.Colors.softLavenderButton)
                    .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
                }
                .buttonStyle(.plain)
                .disabled(isReviewing || reflectionText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                .opacity(
                    (isReviewing || reflectionText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    ? 0.55 : 1
                )
            }
        }
    }

    private func resultBanner(_ result: TaskVerificationResult) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(result.passed ? "Verified" : "Task not proven")
                .font(AppFont.bold(16))
                .foregroundStyle(result.passed ? AppTheme.Colors.successMintIcon : AppTheme.Colors.accentRed)

            Text(result.feedback)
                .font(AppFont.regular(14))
                .foregroundStyle(AppTheme.Colors.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(18)
        .background(
            result.passed
                ? AppTheme.Colors.successMintFill
                : Color(red: 1.0, green: 0.92, blue: 0.92)
        )
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    @MainActor
    private func submitForReview(question: String) async {
        isReviewing = true
        defer { isReviewing = false }

        do {
            let result = try await verificationService.reviewTextProof(
                taskTitle: task.title,
                question: question,
                answer: reflectionText
            )
            withAnimation(.easeInOut(duration: 0.25)) {
                reviewResult = result
            }
        } catch {
            withAnimation(.easeInOut(duration: 0.25)) {
                reviewResult = TaskVerificationResult(
                    passed: false,
                    feedback: error.localizedDescription
                )
            }
        }
    }

    @MainActor
    private func submitPhoto(_ image: UIImage) async {
        isReviewing = true
        reviewResult = nil
        defer { isReviewing = false }

        do {
            let result = try await verificationService.verifyTaskImage(
                task: task.title,
                image: image
            )
            withAnimation(.easeInOut(duration: 0.25)) {
                reviewResult = result
            }
        } catch {
            withAnimation(.easeInOut(duration: 0.25)) {
                reviewResult = TaskVerificationResult(
                    passed: false,
                    feedback: error.localizedDescription
                )
            }
        }
    }
}

struct TaskCompleteOverlay: View {
    let task: FocusTask
    var onVerified: (() -> Void)?
    var onDismiss: (() -> Void)?

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.opacity(0.42)
                .ignoresSafeArea()
                .onTapGesture {
                    onDismiss?()
                }

            VStack(spacing: 0) {
                TaskCompleteSheet(
                    task: task,
                    onVerified: onVerified,
                    onDismiss: onDismiss
                )
            }
            .safeAreaPadding(.bottom, 10)
            .background(Color.white)
            .clipShape(
                UnevenRoundedRectangle(
                    topLeadingRadius: 36,
                    bottomLeadingRadius: 0,
                    bottomTrailingRadius: 0,
                    topTrailingRadius: 36,
                    style: .continuous
                )
            )
            .ignoresSafeArea(edges: .bottom)
            .transition(.move(edge: .bottom).combined(with: .opacity))
        }
        .ignoresSafeArea()
    }
}

#Preview("Photo") {
    ZStack {
        AppTheme.Colors.screenBackground.ignoresSafeArea()
        TaskCompleteOverlay(
            task: FocusTask(
                title: "Clean the bedroom",
                accentColor: AppTheme.Colors.accentOrange,
                verification: .photo,
                subtasks: [FocusSubtask(title: "Done", isCompleted: true)],
                isExpanded: true
            )
        )
    }
}

#Preview("Honor") {
    ZStack {
        AppTheme.Colors.screenBackground.ignoresSafeArea()
        TaskCompleteOverlay(
            task: FocusTask(
                title: "Read Atomic Habits",
                accentColor: AppTheme.Colors.accentBlue,
                verification: .textHonor(
                    question: "What's the main thing you took away from your reading?"
                ),
                subtasks: [FocusSubtask(title: "Done", isCompleted: true)],
                isExpanded: true
            )
        )
    }
}
