//
//  ContentView.swift
//  Rivet1
//

import SwiftUI

struct ContentView: View {
    @State private var selectedTab: AppTab = .dashboard
    @State private var showNewTask = false
    @State private var tasks: [FocusTask] = DashboardView.sampleTasks
    @State private var completedTask: FocusTask?

    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                Group {
                    switch selectedTab {
                    case .dashboard:
                        DashboardView(
                            tasks: $tasks,
                            completedTask: $completedTask,
                            onStartFocus: {},
                            onAddTask: { showNewTask = true }
                        )
                    case .tasks:
                        placeholder(title: "Tasks", symbol: "square.grid.2x2.fill")
                    case .settings:
                        placeholder(title: "Settings", symbol: "gearshape.fill")
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                MainTabBar(selectedTab: $selectedTab)
            }
            .background(rootBackground.ignoresSafeArea())

            if let completedTask {
                TaskCompleteOverlay(
                    task: completedTask,
                    onVerified: {},
                    onDismiss: {
                        withAnimation(.spring(response: 0.35, dampingFraction: 0.9)) {
                            self.completedTask = nil
                        }
                    }
                )
                .transition(.opacity)
                .zIndex(10)
            }
        }
        .animation(.spring(response: 0.35, dampingFraction: 0.9), value: completedTask?.id)
        .fullScreenCover(isPresented: $showNewTask) {
            NavigationStack {
                NewTaskView { draft, plan in
                    let newTask = FocusTask.from(draft: draft, plan: plan)
                    withAnimation(.easeInOut(duration: 0.25)) {
                        tasks.insert(newTask, at: 0)
                    }
                    showNewTask = false
                }
            }
        }
    }

    private var rootBackground: Color {
        selectedTab == .dashboard
            ? AppTheme.Colors.headerTop
            : AppTheme.Colors.screenBackground
    }

    private func placeholder(title: String, symbol: String) -> some View {
        VStack(spacing: 12) {
            Image(systemName: symbol)
                .font(.system(size: 36, weight: .medium))
                .foregroundStyle(AppTheme.Colors.tabInactive)
            Text(title)
                .font(AppFont.semibold(20))
                .foregroundStyle(AppTheme.Colors.textPrimary)
            Text("Coming in the next screen")
                .font(AppFont.regular(14))
                .foregroundStyle(AppTheme.Colors.textMuted)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(AppTheme.Colors.screenBackground)
    }
}

#Preview {
    ContentView()
}
