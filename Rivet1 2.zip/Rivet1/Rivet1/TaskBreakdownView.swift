//
//  TaskBreakdownView.swift
//  Rivet1
//

import SwiftUI

struct TaskBreakdownView: View {
    @Environment(\.dismiss) private var dismiss

    let plan: TaskBreakdownPlan
    var onAddTask: ((TaskBreakdownPlan) -> Void)?

    var body: some View {
        VStack(spacing: 0) {
            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    header
                    summaryCards
                    stepsList
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 24)
            }

            bottomActions
        }
        .background(backgroundGradient.ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
    }

    // MARK: - Header

    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            StatusPill(title: "PLAN READY")

            Text("AI broke this into \(plan.stepCount) focused steps")
                .font(AppFont.regular(14))
                .foregroundStyle(AppTheme.Colors.textSecondary)

            Text(plan.taskTitle)
                .font(AppFont.bold(28))
                .foregroundStyle(AppTheme.Colors.textPrimary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var summaryCards: some View {
        HStack(spacing: 12) {
            SummaryStatCard(
                label: "breakdown",
                value: "\(plan.stepCount) steps",
                systemImage: "list.bullet"
            )
            SummaryStatCard(
                label: "estimated",
                value: plan.estimatedLabel,
                systemImage: "clock"
            )
        }
    }

    private var stepsList: some View {
        LazyVStack(spacing: 12) {
            ForEach(plan.steps) { step in
                BreakdownStepRow(step: step)
            }
        }
        .padding(.top, 4)
    }

    // MARK: - Bottom

    private var bottomActions: some View {
        VStack(spacing: 12) {
            PrimaryGradientButton(
                title: "Add Task",
                systemImage: nil,
                trailingSystemImages: ["bolt.fill", "arrow.right"],
                cornerRadius: 22
            ) {
                onAddTask?(plan)
            }

            SecondaryButton(title: "Back") {
                dismiss()
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 12)
        .padding(.bottom, 10)
        .background(
            AppTheme.Colors.formBackground
                .shadow(color: Color.black.opacity(0.04), radius: 10, x: 0, y: -4)
                .ignoresSafeArea(edges: .bottom)
        )
    }

    private var backgroundGradient: LinearGradient {
        LinearGradient(
            colors: [
                Color(red: 0.90, green: 0.94, blue: 1.0),
                AppTheme.Colors.formBackground
            ],
            startPoint: .top,
            endPoint: .bottom
        )
    }
}

#Preview {
    NavigationStack {
        TaskBreakdownView(
            plan: TaskBreakdownPlan(
                taskTitle: "Super hard task",
                steps: [
                    TaskBreakdownStep(number: 1, title: "Define the goal clearly in one sentence", durationMinutes: 5),
                    TaskBreakdownStep(number: 2, title: "List what you already know or have", durationMinutes: 10),
                    TaskBreakdownStep(number: 3, title: "Identify the first small action you can take now", durationMinutes: 15)
                ],
                verification: .textHonor(question: "What is your concrete first result?")
            )
        )
    }
}
