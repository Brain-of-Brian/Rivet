//
//  GroqClient.swift
//  Rivet1
//

import Foundation

enum GroqClientError: LocalizedError {
    case missingAPIKey
    case invalidURL
    case badStatus(Int, String)
    case emptyResponse
    case decodingFailed
    case imageTooLarge

    var errorDescription: String? {
        switch self {
        case .missingAPIKey:
            return "Missing Groq API key. Add it to Secrets.plist."
        case .invalidURL:
            return "Invalid Groq API URL."
        case .badStatus(let code, let body):
            return "Groq request failed (\(code)): \(body)"
        case .emptyResponse:
            return "Groq returned an empty response."
        case .decodingFailed:
            return "Could not understand Groq’s response."
        case .imageTooLarge:
            return "Photo is too large to verify. Try a smaller image."
        }
    }
}

struct GroqClient {
    static let visionModel = "qwen/qwen3.6-27b"
    static let textModel = "llama-3.3-70b-versatile"

    var apiKey: String = AppSecrets.groqAPIKey
    var model: String = Self.textModel
    var session: URLSession = .shared

    func chatCompletion(
        system: String,
        user: String,
        model: String? = nil,
        temperature: Double = 0.3,
        jsonObject: Bool = true
    ) async throws -> String {
        try await chatCompletion(
            messages: [
                ["role": "system", "content": system],
                ["role": "user", "content": user]
            ],
            model: model,
            temperature: temperature,
            jsonObject: jsonObject
        )
    }

    /// Multimodal chat completion (text + optional images in OpenAI-compatible content parts).
    func chatCompletion(
        messages: [[String: Any]],
        model: String? = nil,
        temperature: Double = 0.2,
        jsonObject: Bool = false
    ) async throws -> String {
        guard !apiKey.isEmpty else { throw GroqClientError.missingAPIKey }
        guard let url = URL(string: "https://api.groq.com/openai/v1/chat/completions") else {
            throw GroqClientError.invalidURL
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 90

        var body: [String: Any] = [
            "model": model ?? self.model,
            "temperature": temperature,
            "messages": messages
        ]

        if jsonObject {
            body["response_format"] = ["type": "json_object"]
        }

        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await session.data(for: request)
        let status = (response as? HTTPURLResponse)?.statusCode ?? -1
        let raw = String(data: data, encoding: .utf8) ?? ""

        guard (200...299).contains(status) else {
            throw GroqClientError.badStatus(status, raw)
        }

        let decoded = try JSONDecoder().decode(GroqChatResponse.self, from: data)
        guard let content = decoded.choices.first?.message.content?
            .trimmingCharacters(in: .whitespacesAndNewlines),
            !content.isEmpty
        else {
            throw GroqClientError.emptyResponse
        }

        return content
    }
}

private struct GroqChatResponse: Decodable {
    struct Choice: Decodable {
        struct Message: Decodable {
            let content: String?
        }

        let message: Message
    }

    let choices: [Choice]
}
