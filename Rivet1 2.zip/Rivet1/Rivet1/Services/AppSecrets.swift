//
//  AppSecrets.swift
//  Rivet1
//

import Foundation

enum AppSecrets {
    static var groqAPIKey: String {
        guard
            let url = Bundle.main.url(forResource: "Secrets", withExtension: "plist"),
            let data = try? Data(contentsOf: url),
            let plist = try? PropertyListSerialization.propertyList(from: data, format: nil) as? [String: Any],
            let key = plist["GROQ_API_KEY"] as? String,
            !key.isEmpty,
            key != "YOUR_GROQ_API_KEY_HERE"
        else {
            return ""
        }
        return key
    }
}
