//
//  TaskVerificationService.swift
//  Rivet1
//

import Foundation
import UIKit

struct TaskVerificationResult: Equatable {
    let passed: Bool
    let feedback: String
}

struct TaskVerificationService {
    private let client: GroqClient

    init(client: GroqClient = GroqClient()) {
        self.client = client
    }

    func reviewTextProof(
        taskTitle: String,
        question: String,
        answer: String
    ) async throws -> TaskVerificationResult {
        let system = """
        You are Rivit AI, verifying whether a user truly completed a task.
        You receive the task title, a proof question, and the user's answer.

        Return ONLY valid JSON:
        {
          "passed": true | false,
          "feedback": "string"
        }

        Rules:
        - Pass ONLY if the answer shows concrete evidence the task was actually done (specific details, outcomes, artifacts, or understanding that is hard to fake).
        - Fail vague, empty, joke, copy-paste, generic, or off-topic answers.
        - feedback should be 1 short sentence.
        - If failed, feedback should clearly communicate that the task was not proven.
        - Do not include markdown or extra keys.
        """

        let user = """
        Task: \(taskTitle)
        Proof question: \(question)
        User answer: \(answer)
        """

        let content = try await client.chatCompletion(
            system: system,
            user: user,
            temperature: 0.2,
            jsonObject: true
        )

        let payload = try decodeJSON(ReviewPayload.self, from: content)
        let feedback = payload.feedback?
            .trimmingCharacters(in: .whitespacesAndNewlines)

        if payload.passed == true {
            return TaskVerificationResult(
                passed: true,
                feedback: (feedback?.isEmpty == false ? feedback! : "Nice work — task verified.")
            )
        }

        return TaskVerificationResult(
            passed: false,
            feedback: (feedback?.isEmpty == false ? feedback! : "Task not proven. Add a more specific answer.")
        )
    }

    /// Verifies a photo against a physical task using Groq `qwen/qwen3.6-27b`.
    func verifyTaskImage(task: String, image: UIImage) async throws -> TaskVerificationResult {
        let base64 = try ImageJPEGEncoder.base64JPEGUnder4MB(from: image)
        let prompt = "Does this image prove the completion of the task: \(task)? Answer only 'yes' or 'no'."

        let messages: [[String: Any]] = [
            [
                "role": "user",
                "content": [
                    [
                        "type": "text",
                        "text": prompt
                    ],
                    [
                        "type": "image_url",
                        "image_url": [
                            "url": "data:image/jpeg;base64,\(base64)"
                        ]
                    ]
                ]
            ]
        ]

        let content = try await client.chatCompletion(
            messages: messages,
            model: GroqClient.visionModel,
            temperature: 0,
            jsonObject: false
        )

        let passed = Self.parseYesNo(content)
        if passed {
            return TaskVerificationResult(
                passed: true,
                feedback: "Photo verified — this looks like the task is done."
            )
        }

        return TaskVerificationResult(
            passed: false,
            feedback: "Task not proven. The photo doesn’t clearly show completion."
        )
    }

    private static func parseYesNo(_ content: String) -> Bool {
        let normalized = content
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()

        // Prefer the first yes/no token in the reply (models sometimes add extra text).
        let tokens = normalized
            .replacingOccurrences(of: ",", with: " ")
            .replacingOccurrences(of: ".", with: " ")
            .replacingOccurrences(of: "!", with: " ")
            .replacingOccurrences(of: "\"", with: " ")
            .replacingOccurrences(of: "'", with: " ")
            .split(separator: " ")
            .map(String.init)

        if let first = tokens.first(where: { $0 == "yes" || $0 == "no" }) {
            return first == "yes"
        }

        if normalized.contains("yes") && !normalized.contains("no") {
            return true
        }

        return false
    }
}

private struct ReviewPayload: Decodable {
    let passed: Bool?
    let feedback: String?
}
