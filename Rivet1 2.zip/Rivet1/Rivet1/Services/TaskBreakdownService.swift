//
//  TaskBreakdownService.swift
//  Rivet1
//

import Foundation

struct TaskBreakdownService {
    private let client: GroqClient

    init(client: GroqClient = GroqClient()) {
        self.client = client
    }

    func breakdown(taskTitle: String, priority: TaskPriority) async throws -> TaskBreakdownPlan {
        let trimmed = taskTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        let title = trimmed.isEmpty ? "Untitled task" : trimmed

        let system = """
        You are Rivit AI, a productivity coach inside a focus app.
        Break a user's task into clear, actionable focus steps, and decide how to verify completion.

        Return ONLY valid JSON with this exact shape:
        {
          "steps": [
            { "title": "string", "durationMinutes": 5 }
          ],
          "verification": {
            "type": "photo" | "honor",
            "question": "string"
          }
        }

        Step rules:
        - Choose however many steps the task needs (typically 2–8). Simple tasks may need 1–2; complex ones may need more.
        - Do NOT force a fixed count like exactly 5.
        - Each step title must be a concrete action the user can start immediately.
        - durationMinutes must be an integer estimate for that step alone.
        - Total time should feel realistic for the task.

        Verification rules:
        - If the task has a physical, visible result (e.g., cleaning, cooking, building), return type "photo".
        - If it is digital, mental, or subjective (e.g., coding, reading, designing), return type "honor".
        - For "honor", the question must be a specific proof prompt that is hard to fake without doing the task.
        - For "photo", include a short question describing what a completion photo should show.
        - Do not include markdown, comments, or extra keys.
        """

        let user = """
        Task: \(title)
        Priority: \(priority.rawValue)
        """

        let content = try await client.chatCompletion(
            system: system,
            user: user,
            temperature: 0.35,
            jsonObject: true
        )

        return try Self.parsePlan(from: content, taskTitle: title)
    }

    private static func parsePlan(from content: String, taskTitle: String) throws -> TaskBreakdownPlan {
        let decoded = try decodeJSON(BreakdownPayload.self, from: content)

        let steps = decoded.steps
            .prefix(10)
            .enumerated()
            .compactMap { index, step -> TaskBreakdownStep? in
                let stepTitle = step.title.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !stepTitle.isEmpty else { return nil }
                let minutes = max(1, min(step.durationMinutes ?? 10, 180))
                return TaskBreakdownStep(
                    number: index + 1,
                    title: stepTitle,
                    durationMinutes: minutes
                )
            }

        guard !steps.isEmpty else {
            throw GroqClientError.decodingFailed
        }

        let verification = mapVerification(decoded.verification)

        return TaskBreakdownPlan(
            taskTitle: taskTitle,
            steps: Array(steps),
            verification: verification
        )
    }

    private static func mapVerification(_ payload: BreakdownPayload.Verification?) -> TaskVerification {
        let type = (payload?.type ?? "honor").trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let question = payload?.question?
            .trimmingCharacters(in: .whitespacesAndNewlines)

        if type == "photo" {
            return .photo
        }

        // "honor", "text", and anything else → text/honor verification
        if let question, !question.isEmpty {
            return .textHonor(question: question)
        }

        return .defaultText
    }
}

enum JSONHelper {
    static func decode<T: Decodable>(_ type: T.Type, from content: String) throws -> T {
        try decodeJSON(type, from: content)
    }
}

func decodeJSON<T: Decodable>(_ type: T.Type, from content: String) throws -> T {
    let data = Data(content.utf8)
    do {
        return try JSONDecoder().decode(type, from: data)
    } catch {
        let cleaned = content
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard let cleanedData = cleaned.data(using: .utf8) else {
            throw GroqClientError.decodingFailed
        }
        do {
            return try JSONDecoder().decode(type, from: cleanedData)
        } catch {
            throw GroqClientError.decodingFailed
        }
    }
}

private struct BreakdownPayload: Decodable {
    struct Step: Decodable {
        let title: String
        let durationMinutes: Int?
    }

    struct Verification: Decodable {
        let type: String?
        let question: String?
    }

    let steps: [Step]
    let verification: Verification?
}
