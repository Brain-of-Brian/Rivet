//
//  ImageJPEGEncoder.swift
//  Rivet1
//

import UIKit

enum ImageJPEGEncoder {
    /// Groq base64 image limit is 4MB for the encoded payload.
    static let maxBase64Bytes = 4 * 1024 * 1024

    /// Compresses a `UIImage` to a JPEG data-URL style base64 string under 4MB.
    static func base64JPEGUnder4MB(from image: UIImage) throws -> String {
        var quality: CGFloat = 0.85
        var working = image

        for _ in 0..<8 {
            guard let data = working.jpegData(compressionQuality: quality) else {
                throw GroqClientError.decodingFailed
            }

            let base64 = data.base64EncodedString()
            if base64.utf8.count < maxBase64Bytes {
                return base64
            }

            // Shrink further: lower quality, then downscale dimensions.
            if quality > 0.35 {
                quality -= 0.15
            } else {
                working = resized(working, scale: 0.7)
                quality = 0.7
            }
        }

        // Final attempt at very aggressive settings.
        let finalImage = resized(working, scale: 0.5)
        guard let data = finalImage.jpegData(compressionQuality: 0.25) else {
            throw GroqClientError.decodingFailed
        }
        let base64 = data.base64EncodedString()
        guard base64.utf8.count < maxBase64Bytes else {
            throw GroqClientError.imageTooLarge
        }
        return base64
    }

    private static func resized(_ image: UIImage, scale: CGFloat) -> UIImage {
        let newSize = CGSize(
            width: max(1, image.size.width * scale),
            height: max(1, image.size.height * scale)
        )
        let renderer = UIGraphicsImageRenderer(size: newSize)
        return renderer.image { _ in
            image.draw(in: CGRect(origin: .zero, size: newSize))
        }
    }
}
