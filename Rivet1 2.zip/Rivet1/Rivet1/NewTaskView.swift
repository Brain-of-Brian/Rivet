//
//  NewTaskView.swift
//  Rivet1
//

import SwiftUI

struct NewTaskView: View {
    @Environment(\.dismiss) private var dismiss

    @State private var draft = NewTaskDraft()
    @State private var breakdownPlan: TaskBreakdownPlan?
    @State private var isBreakingDown = false
    @State private var errorMessage: String?
    @FocusState private var isTaskFocused: Bool

    private let breakdownService = TaskBreakdownService()

    var onSave: ((NewTaskDraft, TaskBreakdownPlan?) -> Void)?

    private var canBreakDown: Bool {
        !draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && !isBreakingDown
    }

    var body: some View {
        VStack(spacing: 0) {
            navigationBar
            Divider().overlay(AppTheme.Colors.fieldBorder.opacity(0.6))

            ScrollView(.vertical, showsIndicators: false) {
                VStack(alignment: .leading, spacing: 28) {
                    taskSection
                    prioritySection
                    colorSection

                    PrimaryGradientButton(
                        title: isBreakingDown ? "Breaking it down…" : "AI: Break it down",
                        systemImage: isBreakingDown ? nil : "sparkle",
                        cornerRadius: 28
                    ) {
                        Task { await breakDownTask() }
                    }
                    .disabled(!canBreakDown)
                    .opacity((!draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isBreakingDown) ? 1 : 0.55)
                    .overlay {
                        if isBreakingDown {
                            ProgressView()
                                .tint(.white)
                        }
                    }
                    .padding(.top, 8)

                    if let errorMessage {
                        Text(errorMessage)
                            .font(AppFont.regular(13))
                            .foregroundStyle(AppTheme.Colors.accentRed)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(.horizontal, 22)
                .padding(.top, 28)
                .padding(.bottom, 40)
            }
        }
        .background(AppTheme.Colors.formBackground.ignoresSafeArea())
        .navigationBarBackButtonHidden(true)
        .toolbar(.hidden, for: .navigationBar)
        .navigationDestination(item: $breakdownPlan) { plan in
            TaskBreakdownView(
                plan: plan,
                onAddTask: { savedPlan in
                    onSave?(draft, savedPlan)
                    dismiss()
                }
            )
        }
        .interactiveDismissDisabled(isBreakingDown)
    }

    // MARK: - AI

    @MainActor
    private func breakDownTask() async {
        errorMessage = nil
        isBreakingDown = true
        defer { isBreakingDown = false }

        do {
            let plan = try await breakdownService.breakdown(
                taskTitle: draft.title,
                priority: draft.priority
            )
            breakdownPlan = plan
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    // MARK: - Nav

    private var navigationBar: some View {
        HStack {
            Button {
                dismiss()
            } label: {
                HStack(spacing: 4) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 14, weight: .semibold))
                    Text("Back")
                        .font(AppFont.medium(16))
                }
                .foregroundStyle(AppTheme.Colors.navAction)
            }
            .buttonStyle(.plain)

            Spacer()

            Text("New Task")
                .font(AppFont.bold(18))
                .foregroundStyle(AppTheme.Colors.textPrimary)

            Spacer()

            Button {
                onSave?(draft, nil)
                dismiss()
            } label: {
                Text("Save")
                    .font(AppFont.semibold(14))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 8)
                    .background(AppTheme.Colors.saveButtonFill)
                    .clipShape(Capsule())
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(AppTheme.Colors.formBackground)
    }

    // MARK: - Sections

    private var taskSection: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("Describe what you need to get done.")
                .font(AppFont.bold(22))
                .foregroundStyle(AppTheme.Colors.textPrimary)
                .fixedSize(horizontal: false, vertical: true)

            VStack(alignment: .leading, spacing: 8) {
                Text("TASK")
                    .font(AppFont.semibold(11))
                    .foregroundStyle(AppTheme.Colors.fieldLabel)
                    .tracking(1.0)

                TextField("", text: $draft.title)
                    .font(AppFont.medium(17))
                    .foregroundStyle(AppTheme.Colors.textPrimary)
                    .focused($isTaskFocused)
                    .submitLabel(.done)

                Rectangle()
                    .fill(draft.selectedColor)
                    .frame(height: 2)
                    .animation(.easeInOut(duration: 0.2), value: draft.colorID)
            }
        }
    }

    private var prioritySection: some View {
        PriorityPicker(selection: $draft.priority)
    }

    private var colorSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("COLOR")
                .font(AppFont.semibold(11))
                .foregroundStyle(AppTheme.Colors.fieldLabel)
                .tracking(1.0)

            ColorSwatchPicker(
                options: TaskColorOption.palette,
                selectedID: $draft.colorID
            )
        }
    }
}

#Preview {
    NavigationStack {
        NewTaskView()
    }
}
