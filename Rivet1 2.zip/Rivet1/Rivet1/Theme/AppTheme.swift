//
//  AppTheme.swift
//  Rivet1
//

import SwiftUI

enum AppTheme {
    enum Colors {
        static let headerTop = Color(red: 0.10, green: 0.12, blue: 0.20)
        static let headerBottom = Color(red: 0.14, green: 0.16, blue: 0.28)
        static let screenBackground = Color(red: 0.96, green: 0.97, blue: 0.98)
        static let formBackground = Color(red: 0.95, green: 0.97, blue: 1.0)
        static let cardBackground = Color.white

        static let textPrimary = Color(red: 0.12, green: 0.16, blue: 0.28)
        static let textSecondary = Color(red: 0.55, green: 0.58, blue: 0.65)
        static let textMuted = Color(red: 0.68, green: 0.71, blue: 0.76)
        static let headerTitle = Color(red: 0.70, green: 0.72, blue: 0.78)
        static let navAction = Color(red: 0.45, green: 0.55, blue: 0.85)
        static let fieldBorder = Color(red: 0.78, green: 0.85, blue: 0.95)
        static let fieldLabel = Color(red: 0.62, green: 0.72, blue: 0.88)
        static let saveButtonFill = Color(red: 0.72, green: 0.82, blue: 0.95)
        static let secondaryButtonFill = Color(red: 0.90, green: 0.93, blue: 0.97)
        static let secondaryButtonBorder = Color(red: 0.78, green: 0.84, blue: 0.92)
        static let planBadgeFill = Color(red: 0.88, green: 0.93, blue: 1.0)
        static let planBadgeText = Color(red: 0.35, green: 0.48, blue: 0.85)
        static let stepBadgeFill = Color(red: 0.88, green: 0.92, blue: 1.0)
        static let sheetBackground = Color(red: 0.97, green: 0.97, blue: 0.99)
        static let successMintFill = Color(red: 0.82, green: 0.95, blue: 0.88)
        static let successMintIcon = Color(red: 0.18, green: 0.62, blue: 0.42)
        static let successBlueFill = Color(red: 0.85, green: 0.91, blue: 1.0)
        static let successBlueIcon = Color(red: 0.32, green: 0.48, blue: 0.92)
        static let aiBadgeFill = Color(red: 0.92, green: 0.90, blue: 1.0)
        static let aiBadgeText = Color(red: 0.55, green: 0.45, blue: 0.92)
        static let infoCardFill = Color(red: 0.93, green: 0.92, blue: 1.0)
        static let infoCardTitle = Color(red: 0.48, green: 0.42, blue: 0.85)
        static let softLavenderButton = Color(red: 0.62, green: 0.68, blue: 0.95)

        static let accentCyan = Color(red: 0.30, green: 0.85, blue: 0.82)
        static let accentBlue = Color(red: 0.36, green: 0.38, blue: 0.95)
        static let accentPurple = Color(red: 0.58, green: 0.42, blue: 0.98)
        static let accentOrange = Color(red: 1.0, green: 0.55, blue: 0.18)
        static let accentRed = Color(red: 0.95, green: 0.35, blue: 0.35)
        static let softBlueFill = Color(red: 0.90, green: 0.92, blue: 1.0)
        static let softBlueText = Color(red: 0.45, green: 0.50, blue: 0.95)
        static let subtaskDone = Color(red: 0.55, green: 0.62, blue: 0.95)
        static let tabInactive = Color(red: 0.72, green: 0.74, blue: 0.78)

        static let focusGradient = LinearGradient(
            colors: [
                Color(red: 0.36, green: 0.38, blue: 0.95),
                Color(red: 0.55, green: 0.40, blue: 0.98)
            ],
            startPoint: .leading,
            endPoint: .trailing
        )

        static let headerGradient = LinearGradient(
            colors: [headerTop, headerBottom],
            startPoint: .top,
            endPoint: .bottom
        )
    }

    enum CornerRadius {
        static let card: CGFloat = 16
        static let button: CGFloat = 18
        static let pill: CGFloat = 100
        static let appCard: CGFloat = 14
        static let headerBottom: CGFloat = 28
    }

    enum Shadow {
        static let card = Color.black.opacity(0.06)
        static let soft = Color.black.opacity(0.04)
        static let glow = Color(red: 0.45, green: 0.40, blue: 0.98).opacity(0.45)
    }
}
