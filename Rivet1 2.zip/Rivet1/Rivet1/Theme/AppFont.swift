//
//  AppFont.swift
//  Rivet1
//

import SwiftUI

enum AppFont {
    static func regular(_ size: CGFloat) -> Font {
        .custom("Epilogue-Regular", size: size)
    }

    static func medium(_ size: CGFloat) -> Font {
        .custom("Epilogue-Medium", size: size)
    }

    static func semibold(_ size: CGFloat) -> Font {
        .custom("Epilogue-SemiBold", size: size)
    }

    static func bold(_ size: CGFloat) -> Font {
        .custom("Epilogue-Bold", size: size)
    }

    static func extrabold(_ size: CGFloat) -> Font {
        .custom("Epilogue-ExtraBold", size: size)
    }
}
