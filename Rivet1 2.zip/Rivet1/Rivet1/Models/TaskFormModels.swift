//
//  TaskFormModels.swift
//  Rivet1
//

import SwiftUI

enum TaskPriority: String, CaseIterable, Identifiable {
    case high = "High"
    case medium = "Medium"
    case low = "Low"

    var id: String { rawValue }

    var color: Color {
        switch self {
        case .high: Color(red: 0.95, green: 0.35, blue: 0.35)
        case .medium: Color(red: 1.0, green: 0.55, blue: 0.18)
        case .low: Color(red: 0.25, green: 0.72, blue: 0.55)
        }
    }
}

struct TaskColorOption: Identifiable, Hashable {
    let id: String
    let color: Color

    static let palette: [TaskColorOption] = [
        TaskColorOption(id: "blue", color: Color(red: 0.35, green: 0.55, blue: 1.0)),
        TaskColorOption(id: "indigo", color: Color(red: 0.45, green: 0.48, blue: 0.95)),
        TaskColorOption(id: "orange", color: Color(red: 1.0, green: 0.55, blue: 0.25)),
        TaskColorOption(id: "teal", color: Color(red: 0.25, green: 0.72, blue: 0.62)),
        TaskColorOption(id: "pink", color: Color(red: 0.95, green: 0.40, blue: 0.55)),
        TaskColorOption(id: "purple", color: Color(red: 0.58, green: 0.35, blue: 0.95))
    ]
}

struct TaskBreakdownStep: Identifiable, Hashable {
    let id = UUID()
    let number: Int
    var title: String
    var durationMinutes: Int

    var durationLabel: String {
        "~\(durationMinutes) min"
    }
}

struct TaskBreakdownPlan: Hashable {
    var taskTitle: String
    var steps: [TaskBreakdownStep]
    var verification: TaskVerification

    var stepCount: Int { steps.count }

    var estimatedMinutes: Int {
        steps.reduce(0) { $0 + $1.durationMinutes }
    }

    var estimatedLabel: String {
        "~\(estimatedMinutes) min"
    }
}

struct NewTaskDraft: Hashable {
    var title: String = ""
    var priority: TaskPriority = .medium
    var colorID: String = TaskColorOption.palette[0].id

    var selectedColor: Color {
        TaskColorOption.palette.first(where: { $0.id == colorID })?.color
            ?? TaskColorOption.palette[0].color
    }
}
