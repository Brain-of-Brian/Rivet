//
//  DashboardModels.swift
//  Rivet1
//

import SwiftUI

struct AppUsageStat: Identifiable {
    let id = UUID()
    let name: String
    let durationLabel: String
    let iconAssetName: String
    var isDimmed: Bool = false
}

struct FocusSubtask: Identifiable {
    let id = UUID()
    var title: String
    var isCompleted: Bool
}

struct FocusTask: Identifiable {
    let id: UUID
    var title: String
    var accentColor: Color
    var priority: TaskPriority
    var verification: TaskVerification
    var subtasks: [FocusSubtask]
    var isExpanded: Bool

    init(
        id: UUID = UUID(),
        title: String,
        accentColor: Color,
        priority: TaskPriority = .medium,
        verification: TaskVerification = .defaultText,
        subtasks: [FocusSubtask],
        isExpanded: Bool
    ) {
        self.id = id
        self.title = title
        self.accentColor = accentColor
        self.priority = priority
        self.verification = verification
        self.subtasks = subtasks
        self.isExpanded = isExpanded
    }

    var completedCount: Int {
        subtasks.filter(\.isCompleted).count
    }

    var isFullyComplete: Bool {
        !subtasks.isEmpty && subtasks.allSatisfy(\.isCompleted)
    }

    var progressLabel: String {
        guard !subtasks.isEmpty else { return "No steps yet" }
        return "\(completedCount)/\(subtasks.count) done"
    }

    var usesPhotoVerification: Bool {
        if case .photo = verification { return true }
        return false
    }

    static func from(draft: NewTaskDraft, plan: TaskBreakdownPlan?) -> FocusTask {
        let trimmed = draft.title.trimmingCharacters(in: .whitespacesAndNewlines)
        let title = trimmed.isEmpty ? (plan?.taskTitle ?? "Untitled task") : trimmed

        let subtasks: [FocusSubtask]
        if let plan {
            subtasks = plan.steps.map { FocusSubtask(title: $0.title, isCompleted: false) }
        } else {
            subtasks = []
        }

        return FocusTask(
            title: title,
            accentColor: draft.selectedColor,
            priority: draft.priority,
            verification: plan?.verification ?? .defaultText,
            subtasks: subtasks,
            isExpanded: !subtasks.isEmpty
        )
    }
}

enum AppTab: Hashable {
    case dashboard
    case tasks
    case settings

    var title: String {
        switch self {
        case .dashboard: "Dashboard"
        case .tasks: "Tasks"
        case .settings: "Settings"
        }
    }

    var symbolName: String {
        switch self {
        case .dashboard: "house.fill"
        case .tasks: "square.grid.2x2.fill"
        case .settings: "gearshape.fill"
        }
    }
}
