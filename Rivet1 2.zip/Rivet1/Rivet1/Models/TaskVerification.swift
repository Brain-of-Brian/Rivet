//
//  TaskVerification.swift
//  Rivet1
//

import SwiftUI

enum TaskVerification: Hashable {
    /// Physical result — photo flow skipped for now.
    case photo
    /// Honor / text proof with an AI-generated question.
    case textHonor(question: String)

    static let defaultText = TaskVerification.textHonor(
        question: "What specific result shows you finished this task?"
    )
}
