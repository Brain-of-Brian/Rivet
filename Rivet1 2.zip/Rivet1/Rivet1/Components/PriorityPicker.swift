//
//  PriorityPicker.swift
//  Rivet1
//

import SwiftUI

struct PriorityPicker: View {
    @Binding var selection: TaskPriority
    @State private var isExpanded = false

    var body: some View {
        VStack(spacing: 8) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    isExpanded.toggle()
                }
            } label: {
                HStack(spacing: 10) {
                    Circle()
                        .fill(selection.color)
                        .frame(width: 10, height: 10)

                    Text(selection.rawValue)
                        .font(AppFont.medium(16))
                        .foregroundStyle(AppTheme.Colors.textPrimary)

                    Spacer()

                    Image(systemName: "chevron.down")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(AppTheme.Colors.fieldLabel)
                        .rotationEffect(.degrees(isExpanded ? 180 : 0))
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .background(AppTheme.Colors.softBlueFill.opacity(0.45))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(AppTheme.Colors.fieldBorder, lineWidth: 1)
                )
            }
            .buttonStyle(.plain)

            if isExpanded {
                VStack(spacing: 0) {
                    ForEach(TaskPriority.allCases) { priority in
                        Button {
                            selection = priority
                            withAnimation(.easeInOut(duration: 0.2)) {
                                isExpanded = false
                            }
                        } label: {
                            HStack(spacing: 10) {
                                Circle()
                                    .fill(priority.color)
                                    .frame(width: 10, height: 10)

                                Text(priority.rawValue)
                                    .font(AppFont.medium(15))
                                    .foregroundStyle(AppTheme.Colors.textPrimary)

                                Spacer()

                                if selection == priority {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 12, weight: .bold))
                                        .foregroundStyle(AppTheme.Colors.accentBlue)
                                }
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 13)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)

                        if priority != TaskPriority.allCases.last {
                            Divider()
                                .overlay(AppTheme.Colors.fieldBorder.opacity(0.7))
                                .padding(.leading, 36)
                        }
                    }
                }
                .background(AppTheme.Colors.cardBackground)
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(AppTheme.Colors.fieldBorder, lineWidth: 1)
                )
                .shadow(color: AppTheme.Shadow.soft, radius: 8, x: 0, y: 3)
                .transition(.opacity.combined(with: .move(edge: .top)))
            }
        }
    }
}

#Preview {
    @Previewable @State var priority: TaskPriority = .medium
    PriorityPicker(selection: $priority)
        .padding()
        .background(AppTheme.Colors.formBackground)
}
