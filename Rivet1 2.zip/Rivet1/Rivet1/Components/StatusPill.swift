//
//  StatusPill.swift
//  Rivet1
//

import SwiftUI

struct StatusPill: View {
    let title: String
    var systemImage: String? = "checkmark"

    var body: some View {
        HStack(spacing: 6) {
            if let systemImage {
                Image(systemName: systemImage)
                    .font(.system(size: 10, weight: .bold))
            }
            Text(title)
                .font(AppFont.semibold(11))
                .tracking(0.8)
        }
        .foregroundStyle(AppTheme.Colors.planBadgeText)
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(AppTheme.Colors.planBadgeFill)
        .clipShape(Capsule())
    }
}

#Preview {
    StatusPill(title: "PLAN READY")
        .padding()
        .background(AppTheme.Colors.formBackground)
}
