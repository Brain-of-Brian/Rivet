//
//  MainTabBar.swift
//  Rivet1
//

import SwiftUI

struct MainTabBar: View {
    @Binding var selectedTab: AppTab

    var body: some View {
        HStack(spacing: 0) {
            ForEach([AppTab.dashboard, .tasks, .settings], id: \.self) { tab in
                tabButton(tab)
            }
        }
        .padding(.top, 10)
        .padding(.bottom, 6)
        .background(
            AppTheme.Colors.cardBackground
                .shadow(color: Color.black.opacity(0.06), radius: 12, x: 0, y: -4)
                .ignoresSafeArea(edges: .bottom)
        )
        .overlay(alignment: .top) {
            Rectangle()
                .fill(Color.black.opacity(0.05))
                .frame(height: 0.5)
        }
    }

    private func tabButton(_ tab: AppTab) -> some View {
        let isSelected = selectedTab == tab

        return Button {
            selectedTab = tab
        } label: {
            VStack(spacing: 4) {
                Image(systemName: tab.symbolName)
                    .font(.system(size: 20, weight: .medium))

                Text(tab.title)
                    .font(AppFont.medium(11))

                Circle()
                    .fill(isSelected ? AppTheme.Colors.accentBlue : Color.clear)
                    .frame(width: 5, height: 5)
            }
            .foregroundStyle(isSelected ? AppTheme.Colors.accentBlue : AppTheme.Colors.tabInactive)
            .frame(maxWidth: .infinity)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    @Previewable @State var tab: AppTab = .dashboard
    VStack {
        Spacer()
        MainTabBar(selectedTab: $tab)
    }
}
