//
//  ColorSwatchPicker.swift
//  Rivet1
//

import SwiftUI

struct ColorSwatchPicker: View {
    let options: [TaskColorOption]
    @Binding var selectedID: String

    var body: some View {
        HStack(spacing: 14) {
            ForEach(options) { option in
                let isSelected = option.id == selectedID

                Button {
                    selectedID = option.id
                } label: {
                    Circle()
                        .fill(option.color)
                        .frame(width: 28, height: 28)
                        .overlay {
                            if isSelected {
                                Circle()
                                    .stroke(option.color.opacity(0.35), lineWidth: 6)
                                    .frame(width: 36, height: 36)
                            }
                        }
                }
                .buttonStyle(.plain)
            }

            Spacer(minLength: 0)
        }
    }
}

#Preview {
    @Previewable @State var selected = TaskColorOption.palette[0].id
    ColorSwatchPicker(options: TaskColorOption.palette, selectedID: $selected)
        .padding()
}
