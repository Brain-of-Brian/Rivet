//
//  StreakBadge.swift
//  Rivet1
//

import SwiftUI

struct StreakBadge: View {
    let count: Int

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: "flame.fill")
                .font(.system(size: 11, weight: .semibold))
            Text("\(count) streak")
                .font(AppFont.semibold(12))
        }
        .foregroundStyle(AppTheme.Colors.accentOrange)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(
            Capsule()
                .fill(Color.black.opacity(0.35))
                .overlay(
                    Capsule()
                        .stroke(AppTheme.Colors.accentOrange.opacity(0.55), lineWidth: 1)
                )
        )
    }
}

#Preview {
    StreakBadge(count: 7)
        .padding()
        .background(AppTheme.Colors.headerTop)
}
