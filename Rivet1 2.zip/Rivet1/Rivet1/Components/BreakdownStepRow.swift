//
//  BreakdownStepRow.swift
//  Rivet1
//

import SwiftUI

struct BreakdownStepRow: View {
    let step: TaskBreakdownStep

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            Text("\(step.number)")
                .font(AppFont.semibold(14))
                .foregroundStyle(AppTheme.Colors.accentBlue)
                .frame(width: 32, height: 32)
                .background(AppTheme.Colors.stepBadgeFill)
                .clipShape(Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(step.title)
                    .font(AppFont.semibold(15))
                    .foregroundStyle(AppTheme.Colors.textPrimary)
                    .fixedSize(horizontal: false, vertical: true)

                Text(step.durationLabel)
                    .font(AppFont.regular(13))
                    .foregroundStyle(AppTheme.Colors.textMuted)
            }

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 14)
        .background(AppTheme.Colors.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: AppTheme.CornerRadius.card, style: .continuous))
        .shadow(color: AppTheme.Shadow.soft, radius: 8, x: 0, y: 3)
    }
}

#Preview {
    BreakdownStepRow(
        step: TaskBreakdownStep(
            number: 1,
            title: "Define the goal clearly in one sentence",
            durationMinutes: 5
        )
    )
    .padding()
    .background(AppTheme.Colors.formBackground)
}
