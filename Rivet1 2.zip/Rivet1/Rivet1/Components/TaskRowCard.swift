//
//  TaskRowCard.swift
//  Rivet1
//

import SwiftUI

struct TaskRowCard: View {
    @Binding var task: FocusTask
    var onToggleExpand: () -> Void
    var onToggleSubtask: (UUID) -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button(action: onToggleExpand) {
                HStack(alignment: .center, spacing: 12) {
                    Circle()
                        .fill(task.accentColor)
                        .frame(width: 10, height: 10)

                    VStack(alignment: .leading, spacing: 3) {
                        Text(task.title)
                            .font(AppFont.semibold(16))
                            .foregroundStyle(AppTheme.Colors.textPrimary)
                            .multilineTextAlignment(.leading)

                        Text(task.progressLabel)
                            .font(AppFont.medium(12))
                            .foregroundStyle(AppTheme.Colors.softBlueText.opacity(0.85))
                    }

                    Spacer(minLength: 8)

                    Image(systemName: task.isExpanded ? "chevron.down" : "chevron.right")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(AppTheme.Colors.textMuted)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 14)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if task.isExpanded {
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(task.subtasks) { subtask in
                        SubtaskRow(
                            title: subtask.title,
                            isCompleted: subtask.isCompleted
                        ) {
                            onToggleSubtask(subtask.id)
                        }
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 12)
                .padding(.leading, 6)
            }
        }
        .background(AppTheme.Colors.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: AppTheme.CornerRadius.card, style: .continuous))
        .shadow(color: AppTheme.Shadow.card, radius: 10, x: 0, y: 4)
    }
}

private struct SubtaskRow: View {
    let title: String
    let isCompleted: Bool
    let onToggle: () -> Void

    var body: some View {
        Button(action: onToggle) {
            HStack(spacing: 10) {
                Image(systemName: isCompleted ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 18, weight: .regular))
                    .foregroundStyle(
                        isCompleted
                            ? AppTheme.Colors.accentBlue
                            : AppTheme.Colors.textMuted.opacity(0.7)
                    )

                Text(title)
                    .font(AppFont.regular(14))
                    .strikethrough(isCompleted, color: AppTheme.Colors.subtaskDone.opacity(0.7))
                    .foregroundStyle(
                        isCompleted
                            ? AppTheme.Colors.subtaskDone
                            : AppTheme.Colors.textSecondary
                    )

                Spacer(minLength: 0)
            }
            .padding(.vertical, 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    @Previewable @State var task = FocusTask(
        title: "Read Atomic Habits",
        accentColor: AppTheme.Colors.accentBlue,
        verification: .textHonor(
            question: "What's the main thing you took away from your reading?"
        ),
        subtasks: [
            FocusSubtask(title: "Read chapter 1", isCompleted: false),
            FocusSubtask(title: "Highlight key ideas", isCompleted: false),
            FocusSubtask(title: "Write a short summary", isCompleted: false)
        ],
        isExpanded: true
    )

    TaskRowCard(task: $task, onToggleExpand: {}, onToggleSubtask: { _ in })
        .padding()
        .background(AppTheme.Colors.screenBackground)
}
