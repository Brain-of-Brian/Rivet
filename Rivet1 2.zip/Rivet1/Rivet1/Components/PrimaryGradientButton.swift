//
//  PrimaryGradientButton.swift
//  Rivet1
//

import SwiftUI

struct PrimaryGradientButton: View {
    let title: String
    var leadingSystemImage: String? = nil
    var trailingSystemImages: [String] = []
    var cornerRadius: CGFloat = AppTheme.CornerRadius.button
    let action: () -> Void

    init(
        title: String,
        systemImage: String? = "play.fill",
        trailingSystemImages: [String] = [],
        cornerRadius: CGFloat = AppTheme.CornerRadius.button,
        action: @escaping () -> Void
    ) {
        self.title = title
        self.leadingSystemImage = systemImage
        self.trailingSystemImages = trailingSystemImages
        self.cornerRadius = cornerRadius
        self.action = action
    }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if let leadingSystemImage {
                    Image(systemName: leadingSystemImage)
                        .font(.system(size: 14, weight: .bold))
                }

                Text(title)
                    .font(AppFont.semibold(17))

                ForEach(trailingSystemImages, id: \.self) { name in
                    Image(systemName: name)
                        .font(.system(size: 13, weight: .bold))
                }
            }
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 16)
            .background(AppTheme.Colors.focusGradient)
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .shadow(color: AppTheme.Shadow.glow, radius: 16, x: 0, y: 8)
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    VStack(spacing: 16) {
        PrimaryGradientButton(title: "Start Focus session") {}
        PrimaryGradientButton(
            title: "AI: Break it down",
            systemImage: "sparkle",
            cornerRadius: 28
        ) {}
        PrimaryGradientButton(
            title: "Add Task",
            systemImage: nil,
            trailingSystemImages: ["bolt.fill", "arrow.right"]
        ) {}
    }
    .padding()
}
