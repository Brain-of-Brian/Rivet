//
//  SummaryStatCard.swift
//  Rivet1
//

import SwiftUI

struct SummaryStatCard: View {
    let label: String
    let value: String
    let systemImage: String

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(label)
                .font(AppFont.medium(12))
                .foregroundStyle(AppTheme.Colors.textMuted)

            HStack(spacing: 8) {
                Image(systemName: systemImage)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(AppTheme.Colors.accentBlue)

                Text(value)
                    .font(AppFont.semibold(16))
                    .foregroundStyle(AppTheme.Colors.textPrimary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(AppTheme.Colors.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: AppTheme.CornerRadius.card, style: .continuous))
        .shadow(color: AppTheme.Shadow.card, radius: 10, x: 0, y: 4)
    }
}

#Preview {
    HStack(spacing: 12) {
        SummaryStatCard(label: "breakdown", value: "5 steps", systemImage: "list.bullet")
        SummaryStatCard(label: "estimated", value: "~35 min", systemImage: "clock")
    }
    .padding()
    .background(AppTheme.Colors.formBackground)
}
