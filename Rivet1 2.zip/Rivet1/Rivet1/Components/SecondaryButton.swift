//
//  SecondaryButton.swift
//  Rivet1
//

import SwiftUI

struct SecondaryButton: View {
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(AppFont.semibold(16))
                .foregroundStyle(AppTheme.Colors.navAction)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 15)
                .background(AppTheme.Colors.secondaryButtonFill)
                .clipShape(RoundedRectangle(cornerRadius: AppTheme.CornerRadius.button, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: AppTheme.CornerRadius.button, style: .continuous)
                        .stroke(AppTheme.Colors.secondaryButtonBorder, lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
    }
}

#Preview {
    SecondaryButton(title: "Back") {}
        .padding()
        .background(AppTheme.Colors.formBackground)
}
