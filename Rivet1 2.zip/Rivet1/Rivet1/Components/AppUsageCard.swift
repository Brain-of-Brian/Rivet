//
//  AppUsageCard.swift
//  Rivet1
//

import SwiftUI

struct AppUsageCard: View {
    let stat: AppUsageStat

    var body: some View {
        VStack(spacing: 8) {
            Image(stat.iconAssetName)
                .resizable()
                .scaledToFill()
                .frame(width: 42, height: 42)
                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                .opacity(stat.isDimmed ? 0.45 : 1)

            Text(stat.name)
                .font(AppFont.medium(11))
                .foregroundStyle(AppTheme.Colors.textPrimary.opacity(stat.isDimmed ? 0.45 : 1))
                .lineLimit(1)

            Text(stat.durationLabel)
                .font(AppFont.bold(11))
                .foregroundStyle(AppTheme.Colors.accentRed.opacity(stat.isDimmed ? 0.4 : 1))
                .tracking(0.3)
        }
        .frame(width: 78)
        .padding(.vertical, 12)
        .padding(.horizontal, 8)
        .background(AppTheme.Colors.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: AppTheme.CornerRadius.appCard, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: AppTheme.CornerRadius.appCard, style: .continuous)
                .stroke(Color.black.opacity(0.04), lineWidth: 1)
        )
        .shadow(color: AppTheme.Shadow.soft, radius: 8, x: 0, y: 3)
        .opacity(stat.isDimmed ? 0.75 : 1)
    }
}

#Preview {
    HStack {
        AppUsageCard(
            stat: AppUsageStat(
                name: "Instagram",
                durationLabel: "1H 58M",
                iconAssetName: "InstagramAppIcon"
            )
        )
    }
    .padding()
    .background(AppTheme.Colors.screenBackground)
}
