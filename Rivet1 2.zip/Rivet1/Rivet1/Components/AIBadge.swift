//
//  AIBadge.swift
//  Rivet1
//

import SwiftUI

struct AIBadge: View {
    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: "sparkle")
                .font(.system(size: 10, weight: .semibold))
            Text("AI")
                .font(AppFont.semibold(12))
        }
        .foregroundStyle(AppTheme.Colors.aiBadgeText)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(AppTheme.Colors.aiBadgeFill)
        .clipShape(Capsule())
        .overlay(
            Capsule()
                .stroke(AppTheme.Colors.aiBadgeText.opacity(0.18), lineWidth: 1)
        )
    }
}

#Preview {
    AIBadge()
        .padding()
}
