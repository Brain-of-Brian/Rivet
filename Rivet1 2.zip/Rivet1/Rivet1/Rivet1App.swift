//
//  Rivet1App.swift
//  Rivet1
//
//  Created by 16 BGCC Loan Library on 7/14/26.
//

import SwiftUI

@main
struct Rivet1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
